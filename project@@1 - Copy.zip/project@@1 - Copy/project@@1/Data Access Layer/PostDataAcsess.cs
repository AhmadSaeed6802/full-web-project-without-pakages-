﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using BlogAPI.Models;

namespace BlogDataAccess.DataAccess
{
    public class PostDataAccess
    {
        string CS = ConfigurationManager.ConnectionStrings["DemoCN"].ConnectionString;
        // private readonly string connectionString = "YourConnectionString";

        private SqlConnection GetConnection()
        {
            return new SqlConnection(CS);
        }
        public int CreatePost(PostModel post)
        {
            using (SqlConnection connection = GetConnection())
            {
                using (SqlCommand command = new SqlCommand("usp_CreatePost", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@PostId", post.PostId);
                    command.Parameters.AddWithValue("@UserId", post.UserId);
                    command.Parameters.AddWithValue("@Title",  post.Title);
                    command.Parameters.AddWithValue("@Content",post.Content);
                    command.Parameters.AddWithValue("@CategoryId",post.CategoryId);
                    command.Parameters.AddWithValue("@PostedDate", post.PostedDate);
                    command.Parameters.AddWithValue("@UpdatedDate", post.UpdatedDate);

                    connection.Open();
                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }

        public List<PostModel> GetAllPosts()
        {
            List<PostModel> posts = new List<PostModel>();

            using (SqlConnection connection = GetConnection())
            {
                using (SqlCommand command = new SqlCommand("usp_GetAllPosts", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            PostModel post = new PostModel
                            {
                                PostId = Convert.ToInt32(reader["PostId"]),
                                UserId = Convert.ToInt32(reader["UserId"]),
                                Title = reader["Title"].ToString(),
                                Content = reader["Content"].ToString(),
                                CategoryId = Convert.ToInt32(reader["CategoryId"]),
                                //PostedDate = Convert.ToDateTime(reader["CreatedDate"]),
                                //UpdatedDate = Convert.ToDateTime(reader["ModifiedDate"])
                            };
                            posts.Add(post);
                        }
                    }
                }
            }

            return posts;
        }
        // Get post by id---------------------------------- 

        public PostModel GetPostById(int postId)
        {
            using (SqlConnection connection = GetConnection())
            {
                using (SqlCommand command = new SqlCommand("usp_GetPostById", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@PostId", postId);

                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Map the data from the database to a PostModel object
                            PostModel post = new PostModel
                            {
                                PostId = Convert.ToInt32(reader["PostId"]),
                                Title = reader["Title"].ToString(),
                                Content = reader["Content"].ToString(),
                                // CreatedAt = Convert.ToDateTime(reader["CreatedAt"]),
                                UserId = Convert.ToInt32(reader["UserId"]),
                                CategoryId = Convert.ToInt32(reader["CategoryId"])
                            };

                            return post;
                        }
                        else
                        {
                            // If no post with the given ID is found, return null or handle as needed.
                            return null;
                        }
                    }
                }
            }
        }

        public void UpdatePost(PostModel post)
        {
            using (SqlConnection connection = GetConnection())
            {
                using (SqlCommand command = new SqlCommand("usp_UpdatePost", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@PostId", post.PostId);
                    command.Parameters.AddWithValue("@Title", post.Title);
                    command.Parameters.AddWithValue("@Content", post.Content);
                    command.Parameters.AddWithValue("@CategoryId", post.CategoryId);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        public void DeletePost(int postId)
        {
            using (SqlConnection connection = GetConnection())
            {
                using (SqlCommand command = new SqlCommand("usp_DeletePost", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@PostId", postId);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        public List<PostModel> GetPostsByCategory(int categoryId)
        {
            List<PostModel> posts = new List<PostModel>();

            using (SqlConnection connection = GetConnection())
            {
                using (SqlCommand command = new SqlCommand("usp_GetPostsByCategory", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CategoryId", categoryId);

                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            PostModel post = new PostModel
                            {
                                PostId = Convert.ToInt32(reader["PostId"]),
                                Title = reader["Title"].ToString(),
                                Content = reader["Content"].ToString(),
                                // CreatedAt = Convert.ToDateTime(reader["CreatedAt"]),
                                UserId = Convert.ToInt32(reader["UserId"]),
                                CategoryId = Convert.ToInt32(reader["CategoryId"])
                            };

                            posts.Add(post);
                        }
                    }
                }
            }

            return posts;
        }

        public List<PostModel> GetPostsByUser(int userId)
        {
            List<PostModel> posts = new List<PostModel>();

            using (SqlConnection connection = GetConnection())
            {
                using (SqlCommand command = new SqlCommand("usp_GetPostsByUser", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@UserId", userId);

                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            PostModel post = new PostModel
                            {
                                PostId = Convert.ToInt32(reader["PostId"]),
                                Title = reader["Title"].ToString(),
                                Content = reader["Content"].ToString(),
                                //    CreatedAt = Convert.ToDateTime(reader["CreatedAt"]),
                                UserId = Convert.ToInt32(reader["UserId"]),
                                CategoryId = Convert.ToInt32(reader["CategoryId"])
                            };

                            posts.Add(post);
                        }
                    }
                }
            }

            return posts;
        }


    }
}