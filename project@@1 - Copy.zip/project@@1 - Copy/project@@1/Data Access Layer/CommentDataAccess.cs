﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using BlogAPI.Models;
using System.Linq;
using System.Web;
using System.Configuration;
namespace BlogDataAccess.DataAccess
{
    public class CommentDataAccess
    {
        string CS = ConfigurationManager.ConnectionStrings["DemoCN"].ConnectionString;
        // private readonly string connectionString = "YourConnectionString";

        private SqlConnection GetConnection()
        {
            return new SqlConnection(CS);
        }

        public int AddComment(CommentModel comment)
        {
            using (SqlConnection connection = new SqlConnection(CS))
            {
                using (SqlCommand command = new SqlCommand("usp_AddComment", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@PostId", comment.PostId);
                    command.Parameters.AddWithValue("@UserId", comment.UserId);
                    command.Parameters.AddWithValue("@Content", comment.Content);
                    command.Parameters.AddWithValue("@CreatedOn", DateTime.Now);

                    connection.Open();
                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }

        public void UpdateComment(CommentModel comment)
        {
            using (SqlConnection connection = new SqlConnection(CS))
            {
                using (SqlCommand command = new SqlCommand("usp_UpdateComment", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@CommentId", comment.CommentId);
                    command.Parameters.AddWithValue("@Content", comment.Content);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        public void DeleteComment(int commentId)
        {
            using (SqlConnection connection = new SqlConnection(CS))
            {
                using (SqlCommand command = new SqlCommand("usp_DeleteComment", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@CommentId", commentId);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        public List<CommentModel> GetCommentsByPost(int postId)
        {
            List<CommentModel> comments = new List<CommentModel>();

            using (SqlConnection connection = new SqlConnection(CS))
            {
                using (SqlCommand command = new SqlCommand("usp_GetCommentsByPost", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@PostId", postId);

                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            CommentModel comment = new CommentModel
                            {
                                CommentId = Convert.ToInt32(reader["CommentId"]),
                                PostId = Convert.ToInt32(reader["PostId"]),
                                UserId = Convert.ToInt32(reader["UserId"]),
                                Content = Convert.ToString(reader["Content"]),
                                CreatedOn = Convert.ToDateTime(reader["CreatedOn"])
                            };

                            comments.Add(comment);
                        }
                    }
                }
            }

            return comments;
        }

        
    }
}
