﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using BlogAPI.Models;

namespace BlogDataAccess.DataAccess
{
    public class CategoryDataAccess

    {
        string CS = ConfigurationManager.ConnectionStrings["DemoCN"].ConnectionString;
        // private readonly string connectionString = "YourConnectionString";

        private SqlConnection GetConnection()
        {
            return new SqlConnection(CS);
        }
        // Category-related methods

        public int AddCategory(CategoryModel name)
        {
            using (SqlConnection connection = GetConnection())
            {
                using (SqlCommand command = new SqlCommand("usp_CreateCategory", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@Name", name);

                    connection.Open();
                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }

        public List<CategoryModel> GetAllCategories()
        {
            List<CategoryModel> categories = new List<CategoryModel>();

            using (SqlConnection connection = GetConnection())
            {
                using (SqlCommand command = new SqlCommand("usp_GetAllCategories", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            CategoryModel category = new CategoryModel
                            {
                                CategoryId = Convert.ToInt32(reader["CategoryId"]),
                                CategoryName = reader["Name"].ToString(),
                                // CreatedDate = Convert.ToDateTime(reader["CreatedDate"])
                            };
                            categories.Add(category);
                        }
                    }
                }
            }

            return categories;
        }
        public void UpdateCategory(CategoryModel category)
        {
            using (SqlConnection connection = new SqlConnection(CS))
            {
                using (SqlCommand command = new SqlCommand("usp_UpdateCategory", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@CategoryId", category.CategoryId);
                    command.Parameters.AddWithValue("@CategoryName", category.CategoryName);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        public void DeleteCategory(int categoryId)
        {
            using (SqlConnection connection = new SqlConnection(CS))
            {
                using (SqlCommand command = new SqlCommand("usp_DeleteCategory", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@CategoryId", categoryId);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }



    }
}