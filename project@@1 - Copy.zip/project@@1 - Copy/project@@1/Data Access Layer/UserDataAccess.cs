﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using BlogAPI.Models;
using System.Web.Configuration;

//namespace BlogDataAccess.DataAccess
//{
//    public class BlogDataAccess
//    {

//namespace project__1.Data_Access_Layer
//{
//    public class BlogDataAccess
//    {
//    }
//}


//using System;
//using System.Collections.Generic;
//using System.Data;
//using System.Data.SqlClient;

namespace BlogDataAccess.DataAccess
{
    public class UserDataAccess
    {
        string CS = ConfigurationManager.ConnectionStrings["DemoCN"].ConnectionString;
        // private readonly string connectionString = "YourConnectionString";

        private SqlConnection GetConnection()
        {
            return new SqlConnection(CS);
        }

        //internal int RegisterUser(UserModel user)
        //{
        //    throw new NotImplementedException();
        //}

        //internal int CreatePost(PostModel post)
        //{
        //    throw new NotImplementedException();
        //}

        // User-related methods

        public int RegisterUser(UserModel User)
        {
            using (SqlConnection connection = GetConnection())
            {
                using (SqlCommand command = new SqlCommand("usp_RegisterUser", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@UserId", User.UserId);
                    command.Parameters.AddWithValue("@UserName", User. UserName);
                    command.Parameters.AddWithValue("@Password", User.Password);
                    command.Parameters.AddWithValue("@Name", User.Name);
                    command.Parameters.AddWithValue("@Email", User. Email);
                    command.Parameters.AddWithValue("@PhoneNumber", User.PhoneNumber);

                    connection.Open();
                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }
        // mehtod to get user by id 
        public UserModel GetUserById(int userId)
        {
            string CS = ConfigurationManager.ConnectionStrings["DemoCN"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(CS))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("sp_GetUserById", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@UserId", userId);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return MapUserFromReader(reader);
                        }
                        return null; // User not found
                    }
                }
            }
        }
        // Helper method to map data from SqlDataReader to User object
        private UserModel MapUserFromReader(SqlDataReader reader)
        {
            return new UserModel
            {
                UserId = Convert.ToInt32(reader["UserId"]),
                UserName = reader["UserName"].ToString(),
                Email = reader["Email"].ToString(),
                // Add other properties as needed
            };
        }

        public int AuthenticateUser(string userName, string password)
        {
            using (SqlConnection connection = GetConnection())
            {
                using (SqlCommand command = new SqlCommand("usp_AuthenticateUser", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@UserName", userName);
                    command.Parameters.AddWithValue("@Password", password);

                    connection.Open();
                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }












    }
}

