﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BlogDataAccess.DataAccess;

//namespace project__1.Business_Layer
//{
//    public class CommentService
//    {
//    }
//}
//using System;
//using System.Collections.Generic;
using BlogAPI.Models;
//using BlogDataAccess.DataAccess;

namespace BlogBusiness.BusinessLogic
{
    public class CommentService
    {
        private readonly CommentDataAccess _commentDataAccess;

        public CommentService(CommentDataAccess commentDataAccess)
        {
            _commentDataAccess = commentDataAccess;
        }

        public int AddComment(CommentModel comment)
        {
            return _commentDataAccess.AddComment(comment);
        }

        public void UpdateComment(CommentModel comment)
        {
            _commentDataAccess.UpdateComment(comment);
        }

        public void DeleteComment(int commentId)
        {
            _commentDataAccess.DeleteComment(commentId);
        }

        public List<CommentModel> GetCommentsByPost(int postId)
        {
            return _commentDataAccess.GetCommentsByPost(postId);
        }

        // Add other methods for updating/deleting comments and other business logic related to comments here.
    }
}
