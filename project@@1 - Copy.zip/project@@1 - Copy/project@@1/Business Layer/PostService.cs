﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BlogDataAccess.DataAccess;
using BlogAPI.Models;


//namespace project__1.Business_Layer
//{
//    public class PostService
//    {
//    }
//}


//using System;
//using System.Collections.Generic;

namespace BlogBusiness.BusinessLogic
{
    public class PostService
    {
        private readonly PostDataAccess _postDataAccess;

        public PostService(PostDataAccess postDataAccess)
        {
            _postDataAccess = postDataAccess;
        }

        public int CreatePost(PostModel post)
        {
            // Implement the logic for creating a new post here.
            // Call the appropriate method from the BlogDataAccess to insert the post into the database.
            return _postDataAccess.CreatePost(post);
        }

        public PostModel GetPostById(int postId)
        {
            // Implement the logic for fetching a post by its ID here.
            // Call the appropriate method from the BlogDataAccess to retrieve the post from the database.
            return _postDataAccess.GetPostById(postId);
        }

        public List<PostModel> GetAllPosts()
        {
            // Implement the logic for fetching all posts here.
            // Call the appropriate method from the BlogDataAccess to retrieve all posts from the database.
            return _postDataAccess.GetAllPosts();
        }

        public void UpdatePost(PostModel post)
        {
            // Implement the logic for updating a post here.
            // Call the appropriate method from the BlogDataAccess to update the post in the database.
            _postDataAccess.UpdatePost(post);
        }

        public void DeletePost(int postId)
        {
            // Implement the logic for deleting a post here.
            // Call the appropriate method from the BlogDataAccess to delete the post from the database.
            _postDataAccess.DeletePost(postId);
        }

        public List<PostModel> GetPostsByCategory(int categoryId)
        {
            // Implement the logic for fetching posts by category here.
            // Call the appropriate method from the BlogDataAccess to retrieve posts by category from the database.
            return _postDataAccess.GetPostsByCategory(categoryId);
        }

        public List<PostModel> GetPostsByUser(int userId)
        {
            // Implement the logic for fetching posts by user here.
            // Call the appropriate method from the BlogDataAccess to retrieve posts by user from the database.
            return _postDataAccess.GetPostsByUser(userId);
        }

        // Add other methods for handling business logic related to posts here.
    }
}
