﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using BlogAPI.Models;
using BlogDataAccess.DataAccess;


namespace BlogBusiness.BusinessLogic
{
    public class CategoryService
    {
        
        private readonly CategoryDataAccess _categoryDataAccess;

        public CategoryService(CategoryDataAccess categoryDataAccess)
        {
            _categoryDataAccess = categoryDataAccess;
        }

        public int AddCategory(CategoryModel category)
        {
            return _categoryDataAccess.AddCategory(category);
        }

        public void UpdateCategory(CategoryModel category)
        {
            _categoryDataAccess.UpdateCategory(category);
        }

        public void DeleteCategory(int categoryId)
        {
            _categoryDataAccess.DeleteCategory(categoryId);
        }

        public List<CategoryModel> GetAllCategories()
        {
            return _categoryDataAccess.GetAllCategories();
        }

        // Add other methods for fetching posts by category, updating/deleting categories, etc., as required.
    }
}
