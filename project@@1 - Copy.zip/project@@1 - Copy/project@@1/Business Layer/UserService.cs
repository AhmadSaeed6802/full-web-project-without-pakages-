﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BlogAPI.Models;
using BlogDataAccess.DataAccess;


//namespace project__1.Business_Layer
//{
//    public class UserService
//    {
//    }
//}
//using System.Collections.Generic;
//using BlogDataAccess.DataAccess;

namespace BlogBusiness.BusinessLogic
{
    public class UserService
    {
        private readonly UserDataAccess _userDataAccess;

        public UserService(UserDataAccess userDataAccess)
        {
            _userDataAccess = userDataAccess;
        }

        public int RegisterUser(UserModel user)
        {
            return _userDataAccess.RegisterUser(user);
        }

        public UserModel GetUserById(int userId)
        {
            return _userDataAccess.GetUserById(userId);
        }
        // LOGIN !!!!!!!!!! Authentication
        //public UserModel AuthenticateUser(string username, string password)
        //{
        //    return _userDataAccess.AuthenticateUser(username, password);
        //}

        //  login or authenticate
            public UserModel AuthenticateUser(string userName, string password)
            {
                int userId = _userDataAccess.AuthenticateUser(userName, password);

                if (userId > 0)
                {
                    // Authentication successful, fetch the user details from the database using the userId.
                    return _userDataAccess.GetUserById(userId);
                }
                else if (userId == 0)
                {
                    // Authentication failed. Return null or throw an exception as needed.
                    return null;
                }
                else
                {
                    // Handle authentication error based on the specific negative value returned.
                    throw new Exception("Authentication error: " + userId);
                }
            }
        
        // Add other methods for updating/deleting users and other business logic related to users here.
        // You can also implement methods to handle user authentication, password hashing, etc.
    }
}
