﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BlogAPI.Models;
using BlogBusiness.BusinessLogic;

namespace BlogAPI.Controllers
{
    public class UserController : ApiController
    {
        private readonly UserService _userService;

        public UserController(UserService userService)
        {
            _userService = userService;
        }

        // POST api/user/register
        [HttpPost]
        public IHttpActionResult RegisterUser(UserModel user)
        {
            try
            {
                int userId = _userService.RegisterUser(user);
                user.UserId = userId;
                return Created(new Uri(Request.RequestUri + "/" + user.UserId), user);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        // GET api/user/{userId}
        [HttpGet]
        public IHttpActionResult GetUserById(int userId)
        {
            try
            {
                var user = _userService.GetUserById(userId);
                if (user == null)
                    return NotFound();
                return Ok(user);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        // POST api/user/authenticate
        [HttpPost]
        public IHttpActionResult AuthenticateUser(UserModel login)
        {
            try
            {
                var user = _userService.AuthenticateUser(login.UserName, login.Password);
                if (user == null)
                    return NotFound();
                return Ok(user);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }
    }
}
