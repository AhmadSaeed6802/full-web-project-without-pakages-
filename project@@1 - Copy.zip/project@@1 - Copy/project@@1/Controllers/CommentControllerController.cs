﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BlogAPI.Models;
using BlogBusiness.BusinessLogic;

namespace BlogAPI.Controllers
{
    public class CommentController : ApiController
    {
        private readonly CommentService _commentService;

        public CommentController(CommentService commentService)
        {
            _commentService = commentService;
        }

        // POST api/comment/add
        [HttpPost]
        public IHttpActionResult AddComment(CommentModel comment)
        {
            try
            {
                int commentId = _commentService.AddComment(comment);
                comment.CommentId = commentId;
                return Created(new Uri(Request.RequestUri + "/" + comment.CommentId), comment);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        // PUT api/comment/update
        [HttpPut]
        public IHttpActionResult UpdateComment(CommentModel comment)
        {
            try
            {
                _commentService.UpdateComment(comment);
                return Ok();
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        // DELETE api/comment/delete/{commentId}
        [HttpDelete]
        public IHttpActionResult DeleteComment(int commentId)
        {
            try
            {
                _commentService.DeleteComment(commentId);
                return Ok();
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        // GET api/comment/post/{postId}
        [HttpGet]
        public IHttpActionResult GetCommentsByPost(int postId)
        {
            try
            {
                var comments = _commentService.GetCommentsByPost(postId);
                return Ok(comments);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }
    }
}
