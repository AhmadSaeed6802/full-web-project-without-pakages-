﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BlogAPI.Models;
using BlogBusiness.BusinessLogic;

namespace BlogAPI.Controllers
{
    public class CategoryController : ApiController
    {
        private readonly CategoryService _categoryService;

        public CategoryController(CategoryService categoryService)
        {
            _categoryService = categoryService;
        }

        // POST api/category/add
        [HttpPost]
        public IHttpActionResult AddCategory(CategoryModel category)
        {
            try
            {
                int categoryId = _categoryService.AddCategory(category);
                category.CategoryId = categoryId;
                return Created(new Uri(Request.RequestUri + "/" + category.CategoryId), category);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        // GET api/category/getall
        [HttpGet]
        public IHttpActionResult GetAllCategories()
        {
            try
            {
                var categories = _categoryService.GetAllCategories();
                return Ok(categories);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        // PUT api/category/update
        [HttpPut]
        public IHttpActionResult UpdateCategory(CategoryModel category)
        {
            try
            {
                _categoryService.UpdateCategory(category);
                return Ok();
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        // DELETE api/category/delete/{categoryId}
        [HttpDelete]
        public IHttpActionResult DeleteCategory(int categoryId)
        {
            try
            {
                _categoryService.DeleteCategory(categoryId);
                return Ok();
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }
    }
}
