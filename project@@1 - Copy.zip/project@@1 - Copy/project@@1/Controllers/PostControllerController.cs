﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BlogAPI.Models;
using BlogBusiness.BusinessLogic;

namespace BlogAPI.Controllers
{
    public class PostController : ApiController
    {
        private readonly PostService _postService;

        public PostController(PostService postService)
        {
            _postService = postService;
        }

        // POST api/post/create
        [HttpPost]
        public IHttpActionResult CreatePost(PostModel post)
        {
            try
            {
                int postId = _postService.CreatePost(post);
                post.PostId = postId;
                return Created(new Uri(Request.RequestUri + "/" + post.PostId), post);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        // GET api/post/{postId}
        [HttpGet]
        public IHttpActionResult GetPostById(int postId)
        {
            try
            {
                var post = _postService.GetPostById(postId);
                if (post == null)
                    return NotFound();
                return Ok(post);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        // GET api/post
        [HttpGet]
        public IHttpActionResult GetAllPosts()
        {
            try
            {
                var posts = _postService.GetAllPosts();
                return Ok(posts);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        // PUT api/post/update
        [HttpPut]
        public IHttpActionResult UpdatePost(PostModel post)
        {
            try
            {
                _postService.UpdatePost(post);
                return Ok();
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        // DELETE api/post/delete/{postId}
        [HttpDelete]
        public IHttpActionResult DeletePost(int postId)
        {
            try
            {
                _postService.DeletePost(postId);
                return Ok();
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        // GET api/post/category/{categoryId}
        [HttpGet]
        public IHttpActionResult GetPostsByCategory(int categoryId)
        {
            try
            {
                var posts = _postService.GetPostsByCategory(categoryId);
                return Ok(posts);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        // GET api/post/user/{userId}
        [HttpGet]
        public IHttpActionResult GetPostsByUser(int userId)
        {
            try
            {
                var posts = _postService.GetPostsByUser(userId);
                return Ok(posts);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }
    }
}
