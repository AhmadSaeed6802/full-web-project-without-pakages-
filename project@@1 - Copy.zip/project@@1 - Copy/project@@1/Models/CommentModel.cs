﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

//namespace project__1.Models
//{
//    public class CommentModel
//    {
//    }
//}
//using System;

namespace BlogAPI.Models
{
    public class CommentModel
    {
        public int CommentId { get; set; }
        public string Content { get; set; }
        public int PostId { get; set; }
        public int UserId { get; set; }
        public DateTime CreatedOn { get;  set; }

       
    }
}
