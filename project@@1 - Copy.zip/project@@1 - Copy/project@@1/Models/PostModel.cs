﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

//namespace project__1.Models
//{
//    public class PostModel
//    {
//    }
//}
//using System;

namespace BlogAPI.Models
{
    public class PostModel
    {
        public int PostId { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
        public int UserId { get; set; }
        public int CategoryId { get; set; }
        public DateTime PostedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
