﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

//namespace project__1.Models
//{
//    public class CategoryModel
//    {
//    }
//}
//using System;

namespace BlogAPI.Models
{
    public class CategoryModel
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
    }
}
